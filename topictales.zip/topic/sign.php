<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="sign.css" />
    <title>Login</title>
  </head>
  <body>
    <div class="container">
      <div class="content">
        <h1>Login to delulu world</h1>
        <div class="tabs">
          <button class="tab__btn active" data-tab="1">Log In</button>
          <span></span>
          <button class="tab__btn" data-tab="2">Sign Up</button>
        </div>
        <div class="tabs__panel">
          <div class="panel active" data-panel="1">
            <form action="login.php" method="post">
              <div class="input__group">
                <input type="text" placeholder=" " />
                <label for="uname" name="uname">Username</label>
              </div>
              <div class="input__group">
                <input type="password" id="login-password" placeholder=" " />
                <label for="password"  name="password" >Password</label>
                <span id="login-password-eye">
                  <i class="ri-eye-off-fill"></i>
                </span>
              </div>
              <button>Log In</button>
              <p>or</p>
              <a href="#">Forgot your password?</a>
            </form>
          </div>
          
          <div class="panel" data-panel="2">
            <form action="signup-check.php" method="post">
                <?php if (isset($_GET['error'])) { ?>
                    <p class="error"><?php echo $_GET['error']; ?></p>
                <?php } ?>
       
                 <?php if (isset($_GET['success'])) { ?>
                      <p class="success"><?php echo $_GET['success']; ?></p>
                 <?php } ?>
       
              <div class="input__group">
                <input type="text" placeholder=" " />
                <label for="text">name</label>
                <?php if (isset($_GET['name'])) { ?>
                    <input type="text" 
                           name="name" 
                           placeholder=" "
                           value="<?php echo $_GET['name']; ?>"><br>
               <?php }else{ ?>
                    <input type="text" 
                           name="name" 
                           placeholder=""><br>
               <?php }?>
              </div>
              <div class="input__group">
                <input type="text" placeholder=" " />
                <label for="text">Username</label>
                
                <?php if (isset($_GET['uname'])) { ?>
                    <input type="text" 
                            name="uname" 
                            placeholder=" "
                            value="<?php echo $_GET['uname']; ?>"><br>
                <?php }else{ ?>
                    <input type="text" 
                            name="uname" 
                            placeholder=""><br>
                <?php }?>
              </div>
              <div class="input__group">
                <input type="password" id="signup-password" placeholder=" " />
                <label for="signup-password" name="password" >Password</label>
                <span id="signup-password-eye">
                  <i class="ri-eye-off-fill"></i>
                </span>
              </div>
              <div class="input__group">
                <input type="password" id="confirm-password" placeholder=" " />
                <label for="confirm-password" name="re_password" >Confirm Password</label>
                <span id="confirm-password-eye">
                  <i class="ri-eye-off-fill"></i>
                </span>
              </div>
              <button>Sign Up</button>
              <p>or</p>
              <a href="#">Already have an account? <span>Login</span></a>
            </form>
          </div>
        </div>
      </div>
      <div class="images"></div>
    </div>

    <script src="sign.js"></script>
  </body>
</html>
